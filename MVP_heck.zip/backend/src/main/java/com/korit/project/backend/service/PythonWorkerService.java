package com.korit.project.backend.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.korit.project.backend.dto.PartMetadata;
import com.korit.project.backend.entity.Part;
import com.korit.project.backend.mapper.CadFileMapper;
import com.korit.project.backend.mapper.PartMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.CompletableFuture;

@Slf4j
@Service
@RequiredArgsConstructor
public class PythonWorkerService {

    private final CadFileMapper cadFileMapper;
    private final PartMapper partMapper;
    private final ObjectMapper objectMapper;

    @Value("${python.worker.script-path}")
    private String scriptPath;

    @Value("${python.executable}")
    private String pythonExecutable;

    @Value("${file.upload.converted-dir}")
    private String convertedDir;

    @Value("${freecad.cmd:FreeCADCmd.exe}")
    private String freecadCmd;

    @Async
    public CompletableFuture<Void> processCadFile(Long cadFileId, String inputFilePath, String originalFilename) {
        return CompletableFuture.runAsync(() -> {
            try {
                log.info("Worker 시작: CAD File ID={}", cadFileId);
                cadFileMapper.updateStatus(cadFileId, "PROCESSING");

                Path inputPath = Paths.get(inputFilePath);
                if (!Files.exists(inputPath)) {
                    log.error("입력 파일을 찾을 수 없습니다: {}", inputFilePath);
                    processCadFileResult(cadFileId, null, "{\"parts\":[]}");
                    return;
                }

                String ext = getExt(originalFilename);

                Path scriptAbsolutePath = Paths.get(scriptPath);
                if (!scriptAbsolutePath.isAbsolute()) {
                    String userDir = System.getProperty("user.dir");
                    scriptAbsolutePath = Paths.get(userDir, scriptPath);
                }

                if (isStepLike(ext)) {
                    runStepToParts(cadFileId, inputPath, scriptAbsolutePath);
                    return;
                }

                runMeshToGlbAndMetadata(cadFileId, inputPath, originalFilename, scriptAbsolutePath);

            } catch (Exception e) {
                log.error("Worker 실행 중 오류: CAD File ID={}", cadFileId, e);
                try {
                    processCadFileResult(cadFileId, null, "{\"parts\":[]}");
                } catch (Exception ex) {
                    log.error("오류 처리 실패", ex);
                }
            }
        });
    }

    private void runStepToParts(Long cadFileId, Path inputPath, Path cadConverterAbsPath) throws Exception {
        Path stepToPartsPath = cadConverterAbsPath.getParent().resolve("step_to_parts.py");

        Path uploadDir = inputPath.getParent();   // .../temp/upload
        Path tempRoot = uploadDir.getParent();    // .../temp

        // parts/{cadFileId}
        Path partsDir = tempRoot.resolve("parts").resolve(String.valueOf(cadFileId));
        Files.createDirectories(partsDir);

        // converted/{cadFileId}  (너가 말한 구조대로)
        Path convertedRoot = Paths.get(convertedDir);
        if (!convertedRoot.isAbsolute()) {
            convertedRoot = Paths.get(System.getProperty("user.dir"), convertedDir);
        }
        Path convertedCadDir = convertedRoot.resolve(String.valueOf(cadFileId));
        Files.createDirectories(convertedCadDir);

        Path jsonOut = partsDir.resolve("parts.json");

        // (너희가 이미 GLB 생성까지 끝냈다고 했으니, 여기서는 예시로만)
        // 만약 여기에서 GLB까지 만드는 별도 step_to_glb.py를 호출한다면
        // glbFilePath = convertedCadDir.resolve("assembly.glb") 로 맞추면 됨.
        // 지금은 너가 “GLB 생성 확인됨”이라 했으니,
        // 실제 구현은 이미 너희 코드에 있을 가능성이 높음.

        String in = inputPath.toAbsolutePath().toString().replace("\\", "/");
        String outDir = partsDir.toAbsolutePath().toString().replace("\\", "/");
        String jsonPath = jsonOut.toAbsolutePath().toString().replace("\\", "/");
        String script = stepToPartsPath.toAbsolutePath().toString().replace("\\", "/");

        String freecadInline =
                "import runpy, sys; " +
                        "sys.argv=[" +
                        "r'step_to_parts.py'," +
                        "r'" + in + "'," +
                        "r'" + outDir + "'," +
                        "r'--format', r'stl'," +
                        "r'--linear', r'10.0'," +
                        "r'--json-out', r'" + jsonPath + "'" +
                        "]; " +
                        "runpy.run_path(r'" + script + "', run_name='__main__')";

        log.info("STEP 처리 시작: cadFileId={}, FreeCADCmd={}", cadFileId, freecadCmd);

        ProcessBuilder pb = new ProcessBuilder(freecadCmd, "-c", freecadInline);
        pb.redirectErrorStream(true);

        Process p = pb.start();
        StringBuilder out = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) out.append(line).append("\n");
        }

        int exit = p.waitFor();
        if (exit != 0) {
            log.error("FreeCADCmd 실패: exitCode={}, output={}", exit, out);
            processCadFileResult(cadFileId, null, "{\"parts\":[]}");
            return;
        }

        if (!Files.exists(jsonOut)) {
            log.error("parts.json 생성 실패: {}", jsonOut.toAbsolutePath());
            processCadFileResult(cadFileId, null, "{\"parts\":[]}");
            return;
        }

        String metadataJson = Files.readString(jsonOut, StandardCharsets.UTF_8).trim();

        // ✅ 너희는 여기서 이미 assembly.glb를 만들고 있다고 했으니,
        // processCadFileResult에 glbFilePath를 “실제 assembly.glb 경로”로 넘겨줘야
        // 아래 B안(=GLB 파싱 nodeIndex 업데이트)가 작동함.
        //
        // 예: converted/{id}/assembly.glb
        Path glb = Paths.get(convertedDir);
        if (!glb.isAbsolute()) glb = Paths.get(System.getProperty("user.dir"), convertedDir);
        Path glbFile = glb.resolve(String.valueOf(cadFileId)).resolve("assembly.glb");

        String glbFilePath = Files.exists(glbFile) ? glbFile.toString() : null;
        processCadFileResult(cadFileId, glbFilePath, metadataJson);
    }

    private void runMeshToGlbAndMetadata(Long cadFileId, Path inputPath, String originalFilename, Path scriptAbsolutePath) throws Exception {
        Path convertedPath = Paths.get(convertedDir);
        if (!convertedPath.isAbsolute()) {
            convertedPath = Paths.get(System.getProperty("user.dir"), convertedDir);
        }
        Files.createDirectories(convertedPath);

        String glbFileName = cadFileId + "_" + originalFilename.replaceAll("\\.[^.]+$", ".glb");
        String glbFilePath = convertedPath.resolve(glbFileName).toString();

        ProcessBuilder processBuilder = new ProcessBuilder(
                pythonExecutable,
                scriptAbsolutePath.toString(),
                inputPath.toAbsolutePath().toString(),
                glbFilePath
        );

        processBuilder.redirectErrorStream(true);
        Process process = processBuilder.start();

        StringBuilder output = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) output.append(line).append("\n");
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            log.error("cad_converter 실패: exitCode={}, output={}", exitCode, output);
            processCadFileResult(cadFileId, null, "{\"parts\":[]}");
            return;
        }

        String metadataJson = output.toString().trim();
        processCadFileResult(cadFileId, glbFilePath, metadataJson);
    }

    private boolean isStepLike(String ext) {
        return ext.equals("step") || ext.equals("stp") || ext.equals("igs") || ext.equals("iges");
    }

    private String getExt(String filename) {
        if (filename == null) return "";
        int idx = filename.lastIndexOf('.');
        if (idx < 0) return "";
        return filename.substring(idx + 1).toLowerCase();
    }

    // =====================================================
    // ✅ B안 핵심: GLB에서 node.name -> nodeIndex 추출
    // =====================================================
    private Map<String, Integer> extractNodeIndexMapFromGlb(Path glbPath) {
        try {
            byte[] bytes = Files.readAllBytes(glbPath);
            if (bytes.length < 12) return Map.of();

            ByteBuffer buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);

            int magic = buf.getInt(0);
            if (magic != 0x46546C67) { // 'glTF'
                log.warn("GLB magic mismatch: {}", glbPath);
                return Map.of();
            }

            int offset = 12;
            byte[] jsonChunk = null;

            while (offset + 8 <= bytes.length) {
                int chunkLength = buf.getInt(offset);
                int chunkType = buf.getInt(offset + 4);
                offset += 8;

                if (offset + chunkLength > bytes.length) break;

                // "JSON" = 0x4E4F534A
                if (chunkType == 0x4E4F534A) {
                    jsonChunk = Arrays.copyOfRange(bytes, offset, offset + chunkLength);
                    break;
                }

                offset += chunkLength;
            }

            if (jsonChunk == null) return Map.of();

            JsonNode root = objectMapper.readTree(new ByteArrayInputStream(jsonChunk));
            JsonNode nodes = root.path("nodes");
            if (!nodes.isArray()) return Map.of();

            Map<String, Integer> map = new HashMap<>();
            for (int i = 0; i < nodes.size(); i++) {
                JsonNode n = nodes.get(i);
                String name = n.path("name").asText(null);
                if (name == null || name.isBlank()) continue;
                map.put(name, i);
            }
            return map;

        } catch (Exception e) {
            log.warn("GLB node index 추출 실패(무시): path={}, err={}", glbPath, e.toString());
            return Map.of();
        }
    }

    @Transactional
    private void processCadFileResult(Long cadFileId, String glbFilePath, String metadataJson) {
        try {
            PartMetadata metadata = objectMapper.readValue(metadataJson, PartMetadata.class);

            if (glbFilePath != null) {
                cadFileMapper.updateGlbPath(cadFileId, glbFilePath);
            }

            partMapper.deleteByCadFileId(cadFileId);

            // 1) parts insert
            if (metadata.getParts() != null && !metadata.getParts().isEmpty()) {
                int fallbackIndex = 0;

                for (PartMetadata.PartInfo partInfo : metadata.getParts()) {
                    Part part = new Part();
                    part.setCadFileId(cadFileId);

                    part.setName(partInfo.getName());
                    part.setDisplayName(null);

                    String partKey = partInfo.getPartKey();
                    if (partKey == null || partKey.isBlank()) {
                        fallbackIndex++;
                        String base = (partInfo.getName() == null || partInfo.getName().isBlank())
                                ? "Part"
                                : partInfo.getName().trim();
                        partKey = "fallback:" + base + ":" + fallbackIndex;
                    }

                    part.setPartKey(partKey);
                    part.setNodeIndex(partInfo.getNodeIndex()); // 초기엔 null일 수 있음
                    part.setNodePath(partInfo.getNodePath());
                    part.setParentPartId(null);

                    if (partInfo.getPosition() != null && partInfo.getPosition().length >= 3) {
                        part.setPositionX(partInfo.getPosition()[0]);
                        part.setPositionY(partInfo.getPosition()[1]);
                        part.setPositionZ(partInfo.getPosition()[2]);
                    }

                    if (partInfo.getSize() != null && partInfo.getSize().length >= 3) {
                        part.setSizeX(partInfo.getSize()[0]);
                        part.setSizeY(partInfo.getSize()[1]);
                        part.setSizeZ(partInfo.getSize()[2]);
                    }

                    partMapper.insertPart(part);
                }
            }

            // 2) ✅ B안: GLB에서 nodeIndex 추출 후 parts.node_index 업데이트
            if (glbFilePath != null) {
                try {
                    Path glbPath = Paths.get(glbFilePath);
                    if (Files.exists(glbPath)) {
                        Map<String, Integer> nodeIndexMap = extractNodeIndexMapFromGlb(glbPath);

                        int updated = 0;
                        for (Map.Entry<String, Integer> e : nodeIndexMap.entrySet()) {
                            updated += partMapper.updateNodeIndexByCadFileIdAndPartKey(
                                    cadFileId, e.getKey(), e.getValue()
                            );
                        }

                        log.info("node_index(GLB 기반) 업데이트 완료: cadFileId={}, updatedRows={}", cadFileId, updated);
                    } else {
                        log.warn("glb 파일이 없어 node_index 업데이트 생략: {}", glbFilePath);
                    }
                } catch (Exception ignore) {
                    log.warn("node_index 업데이트 실패(무시): cadFileId={}", cadFileId);
                }
            }

            cadFileMapper.updateStatus(cadFileId, "COMPLETED");
            log.info("CAD 파일 처리 완료: ID={}", cadFileId);

        } catch (Exception e) {
            log.error("CAD 파일 처리 결과 저장 실패: ID={}", cadFileId, e);
            cadFileMapper.updateStatus(cadFileId, "FAILED");
            throw new RuntimeException("파일 처리 결과 저장 실패", e);
        }
    }
}
