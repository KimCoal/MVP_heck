package com.korit.project.backend.dto;

import lombok.Data;

@Data
public class PartRenameRequest {
    private String displayName;
}
