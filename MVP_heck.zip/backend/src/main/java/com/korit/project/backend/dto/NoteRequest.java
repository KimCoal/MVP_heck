package com.korit.project.backend.dto;

import lombok.Data;

@Data
public class NoteRequest {
    private String note;
}
